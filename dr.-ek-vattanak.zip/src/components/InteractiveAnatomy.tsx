import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Info, Activity, AlertCircle, Globe2, ShieldCheck } from 'lucide-react';

const organData: Record<string, any> = {
  esophagus: {
    name: { en: "Esophagus", kh: "បំពង់អាហារ", fr: "Œsophage" },
    function: { 
      en: "Moves food from the mouth to the stomach using muscle waves called peristalsis.",
      kh: "បញ្ជូនអាហារពីមាត់ទៅក្រពះដោយប្រើរលកសាច់ដុំដែលហៅថា peristalsis។",
      fr: "Déplace les aliments de la bouche vers l'estomac à l'aide d'ondes musculaires appelées péristaltisme."
    },
    conditions: {
      en: ["Acid Reflux", "GERD", "Esophagitis"],
      kh: ["ច្រាលអាស៊ីត", "GERD", "រលាកបំពង់អាហារ"],
      fr: ["Reflux Acide", "RGO", "Œsophagite"]
    },
    prevention: {
      en: "Avoid eating large meals before bedtime and limit spicy or acidic foods.",
      kh: "ជៀសវាងការញ៉ាំអាហារច្រើនមុនពេលចូលគេង និងកាត់បន្ថយអាហារហឹរ ឬជូរ។",
      fr: "Évitez les gros repas avant de vous coucher et limitez les aliments épicés ou acides."
    },
    color: "#94a3b8" // slate-400
  },
  liver: {
    name: { en: "Liver", kh: "ថ្លើម", fr: "Foie" },
    function: {
      en: "Filters blood, detoxifies chemicals, and secretes bile.",
      kh: "ចម្រោះឈាម បន្សាបជាតិពុល និងបញ្ចេញទឹកប្រមាត់។",
      fr: "Filtre le sang, détoxifie les produits chimiques et sécrète la bile."
    },
    conditions: {
      en: ["Fatty Liver Disease", "Hepatitis", "Cirrhosis"],
      kh: ["ជំងឺខ្លាញ់រុំថ្លើម", "រលាកថ្លើម", "ក្រិនថ្លើម"],
      fr: ["Stéatose Hépatique", "Hépatite", "Cirrhose"]
    },
    prevention: {
      en: "Limit alcohol consumption, maintain a healthy weight, and get vaccinated for Hepatitis A and B.",
      kh: "កាត់បន្ថយការផឹកស្រា រក្សាទម្ងន់ឱ្យបានល្អ និងចាក់វ៉ាក់សាំងការពារជំងឺរលាកថ្លើមប្រភេទ A និង B។",
      fr: "Limitez la consommation d'alcool, maintenez un poids santé et faites-vous vacciner contre l'hépatite A et B."
    },
    color: "#fb923c" // orange-400
  },
  gallbladder: {
    name: { en: "Gallbladder", kh: "ថង់ប្រមាត់", fr: "Vésicule Biliaire" },
    function: {
      en: "Stores and concentrates bile produced by the liver to help digest fats.",
      kh: "ផ្ទុក និងប្រមូលផ្តុំទឹកប្រមាត់ដែលផលិតដោយថ្លើម ដើម្បីជួយរំលាយជាតិខ្លាញ់។",
      fr: "Stocke et concentre la bile produite par le foie pour aider à digérer les graisses."
    },
    conditions: {
      en: ["Gallstones", "Cholecystitis", "Biliary Colic"],
      kh: ["គ្រួសក្នុងថង់ប្រមាត់", "រលាកថង់ប្រមាត់", "ការឈឺចាប់បំពង់ប្រមាត់"],
      fr: ["Calculs Biliaires", "Cholécystite", "Colique Biliaire"]
    },
    prevention: {
      en: "Eat a high-fiber diet with healthy fats and avoid rapid weight loss.",
      kh: "ញ៉ាំអាហារដែលមានជាតិសរសៃខ្ពស់ជាមួយខ្លាញ់ល្អ និងជៀសវាងការសម្រកទម្ងន់លឿនពេក។",
      fr: "Mangez une alimentation riche en fibres avec des graisses saines et évitez une perte de poids rapide."
    },
    color: "#14b8a6" // teal-500
  },
  stomach: {
    name: { en: "Stomach", kh: "ក្រពះ", fr: "Estomac" },
    function: {
      en: "Secretes acid and enzymes that digest food.",
      kh: "បញ្ចេញអាស៊ីត និងអង់ស៊ីមដែលរំលាយអាហារ។",
      fr: "Sécrète de l'acide et des enzymes qui digèrent les aliments."
    },
    conditions: {
      en: ["Gastritis", "Peptic Ulcers", "GERD"],
      kh: ["រលាកក្រពះ", "ដំបៅក្រពះ", "GERD"],
      fr: ["Gastrite", "Ulcères Gastro-duodénaux", "RGO"]
    },
    prevention: {
      en: "Eat smaller, more frequent meals and manage stress levels.",
      kh: "ញ៉ាំអាហារតិចតួចតែញឹកញាប់ និងគ្រប់គ្រងភាពតានតឹង។",
      fr: "Prenez des repas plus petits et plus fréquents et gérez votre niveau de stress."
    },
    color: "#f43f5e" // rose-500
  },
  pancreas: {
    name: { en: "Pancreas", kh: "លំពែង", fr: "Pancréas" },
    function: {
      en: "Produces digestive enzymes and regulates blood sugar.",
      kh: "ផលិតអង់ស៊ីមរំលាយអាហារ និងគ្រប់គ្រងជាតិស្ករក្នុងឈាម។",
      fr: "Produit des enzymes digestives et régule la glycémie."
    },
    conditions: {
      en: ["Pancreatitis", "Pancreatic Cancer"],
      kh: ["រលាកលំពែង", "មហារីកលំពែង"],
      fr: ["Pancréatite", "Cancer du Pancréas"]
    },
    prevention: {
      en: "Avoid excessive alcohol, quit smoking, and maintain a low-fat diet.",
      kh: "ជៀសវាងការផឹកស្រាច្រើនពេក ឈប់ជក់បារី និងរក្សារបបអាហារដែលមានជាតិខ្លាញ់ទាប។",
      fr: "Évitez l'excès d'alcool, arrêtez de fumer et maintenez une alimentation pauvre en graisses."
    },
    color: "#eab308" // yellow-500
  },
  small_intestine: {
    name: { en: "Small Intestine", kh: "ពោះវៀនតូច", fr: "Intestin Grêle" },
    function: {
      en: "Absorbs most of the nutrients and minerals from food.",
      kh: "ស្រូបយកសារធាតុចិញ្ចឹម និងសារធាតុរ៉ែភាគច្រើនពីអាហារ។",
      fr: "Absorbe la plupart des nutriments et des minéraux des aliments."
    },
    conditions: {
      en: ["Celiac Disease", "Crohn's Disease", "SIBO"],
      kh: ["ជំងឺ Celiac", "ជំងឺ Crohn", "SIBO"],
      fr: ["Maladie Cœliaque", "Maladie de Crohn", "SIBO"]
    },
    prevention: {
      en: "Chew food thoroughly and consume a balanced diet rich in vitamins.",
      kh: "ទំពារអាហារឱ្យបានម៉ត់ល្អ និងញ៉ាំរបបអាហារដែលមានតុល្យភាពសម្បូរវីតាមីន។",
      fr: "Mâchez bien les aliments et consommez une alimentation équilibrée riche en vitamines."
    },
    color: "#3b82f6" // blue-500
  },
  large_intestine: {
    name: { en: "Large Intestine", kh: "ពោះវៀនធំ", fr: "Gros Intestin" },
    function: {
      en: "Absorbs water and forms stool from indigestible food matter.",
      kh: "ស្រូបយកទឹក និងបង្កើតលាមកពីកាកសំណល់អាហារដែលមិនអាចរំលាយបាន។",
      fr: "Absorbe l'eau et forme les selles à partir des matières alimentaires non digestibles."
    },
    conditions: {
      en: ["IBS", "Colorectal Cancer", "Diverticulitis"],
      kh: ["IBS", "មហារីកពោះវៀនធំ", "រលាក Diverticulitis"],
      fr: ["SII", "Cancer Colorectal", "Diverticulite"]
    },
    prevention: {
      en: "Stay hydrated, eat plenty of fiber, and get regular colon cancer screenings.",
      kh: "ផឹកទឹកឱ្យបានគ្រប់គ្រាន់ ញ៉ាំជាតិសរសៃឱ្យបានច្រើន និងពិនិត្យមហារីកពោះវៀនធំជាប្រចាំ។",
      fr: "Restez hydraté, mangez beaucoup de fibres et faites des dépistages réguliers du cancer colorectal."
    },
    color: "#10b981" // emerald-500
  }
};

const uiText = {
  en: {
    placeholder: "Select an organ to view detailed medical information.",
    function: "Function",
    conditions: "Common Conditions",
    prevention: "Prevention Tips"
  },
  kh: {
    placeholder: "ជ្រើសរើសសរីរាង្គដើម្បីមើលព័ត៌មានវេជ្ជសាស្ត្រលម្អិត។",
    function: "មុខងារ",
    conditions: "ជំងឺទូទៅ",
    prevention: "គន្លឹះការពារ"
  },
  fr: {
    placeholder: "Sélectionnez un organe pour voir les informations médicales détaillées.",
    function: "Fonction",
    conditions: "Conditions Courantes",
    prevention: "Conseils de Prévention"
  }
};

export default function InteractiveAnatomy({ lang }: { lang: 'en' | 'kh' | 'fr' }) {
  const [activeOrgan, setActiveOrgan] = useState<string | null>(null);

  return (
    <div className="flex flex-col items-center gap-8">
      <div className="flex flex-col lg:flex-row items-center justify-center gap-12 bg-white dark:bg-slate-800/50 rounded-3xl p-8 shadow-xl border border-slate-100 dark:border-slate-700 w-full">
        
        {/* Semi-Realistic SVG Anatomy */}
        <div className="relative w-full max-w-md aspect-[3/4] bg-slate-50 dark:bg-slate-900 rounded-2xl overflow-hidden shadow-inner border border-slate-200 dark:border-slate-700">
          {/* Background Medical Torso Image */}
          <img 
            src="https://images.unsplash.com/photo-1530026405186-ed1f139313f8?auto=format&fit=crop&q=80&w=800" 
            alt="Human Torso Anatomy Background" 
            className="absolute inset-0 w-full h-full object-cover opacity-20 dark:opacity-10 mix-blend-luminosity"
          />
          
          <svg viewBox="0 0 400 533" className="absolute inset-0 w-full h-full drop-shadow-2xl z-10">
            <defs>
              <radialGradient id="grad-liver" cx="40%" cy="40%" r="60%">
                <stop offset="0%" stopColor="rgba(220, 38, 38, 0.8)" />
                <stop offset="100%" stopColor="rgba(153, 27, 27, 0.9)" />
              </radialGradient>
              <radialGradient id="grad-stomach" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="rgba(244, 63, 94, 0.8)" />
                <stop offset="100%" stopColor="rgba(190, 18, 60, 0.9)" />
              </radialGradient>
              <radialGradient id="grad-gallbladder" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(45, 212, 191, 0.9)" />
                <stop offset="100%" stopColor="rgba(15, 118, 110, 0.9)" />
              </radialGradient>
              <radialGradient id="grad-pancreas" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="rgba(250, 204, 21, 0.9)" />
                <stop offset="100%" stopColor="rgba(161, 98, 7, 0.9)" />
              </radialGradient>
              <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="5" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Esophagus */}
            <motion.path 
              d="M190,40 C190,40 200,120 205,160 C210,200 215,220 215,220" 
              fill="none"
              stroke={activeOrgan === 'esophagus' ? organData.esophagus.color : 'rgba(148, 163, 184, 0.8)'} 
              strokeWidth="18" 
              strokeLinecap="round" 
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.02, strokeWidth: 22 }}
              onClick={() => setActiveOrgan('esophagus')}
              filter={activeOrgan === 'esophagus' ? 'url(#glow)' : ''}
            />
            
            {/* Liver */}
            <motion.path 
              d="M100,220 C100,180 220,170 260,200 C300,230 240,280 160,280 C120,280 100,260 100,220 Z" 
              fill={activeOrgan === 'liver' ? organData.liver.color : 'url(#grad-liver)'}
              stroke={activeOrgan === 'liver' ? '#fff' : 'rgba(255,255,255,0.3)'}
              strokeWidth="2"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.02 }}
              onClick={() => setActiveOrgan('liver')}
              filter={activeOrgan === 'liver' ? 'url(#glow)' : ''}
            />
            
            {/* Gallbladder */}
            <motion.path 
              d="M160,270 C160,260 180,260 180,275 C180,290 170,300 160,290 C150,280 160,270 160,270 Z" 
              fill={activeOrgan === 'gallbladder' ? organData.gallbladder.color : 'url(#grad-gallbladder)'}
              stroke={activeOrgan === 'gallbladder' ? '#fff' : 'rgba(255,255,255,0.4)'}
              strokeWidth="2"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.1 }}
              onClick={() => setActiveOrgan('gallbladder')}
              filter={activeOrgan === 'gallbladder' ? 'url(#glow)' : ''}
            />
            
            {/* Stomach */}
            <motion.path 
              d="M215,220 C280,200 320,240 290,290 C260,340 190,300 215,260 Z" 
              fill={activeOrgan === 'stomach' ? organData.stomach.color : 'url(#grad-stomach)'}
              stroke={activeOrgan === 'stomach' ? '#fff' : 'rgba(255,255,255,0.3)'}
              strokeWidth="2"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.02 }}
              onClick={() => setActiveOrgan('stomach')}
              filter={activeOrgan === 'stomach' ? 'url(#glow)' : ''}
            />
            
            {/* Pancreas (behind stomach) */}
            <motion.path 
              d="M180,260 C220,250 280,270 270,290 C260,310 170,280 180,260 Z" 
              fill={activeOrgan === 'pancreas' ? organData.pancreas.color : 'url(#grad-pancreas)'}
              stroke={activeOrgan === 'pancreas' ? '#fff' : 'rgba(255,255,255,0.3)'}
              strokeWidth="2"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.05 }}
              onClick={() => setActiveOrgan('pancreas')}
              filter={activeOrgan === 'pancreas' ? 'url(#glow)' : ''}
            />
            
            {/* Large Intestine (Colon) */}
            <motion.path 
              d="M110,380 C90,320 110,290 140,290 C140,290 260,290 290,290 C320,290 330,320 310,380 C290,440 260,450 210,450 C160,450 130,440 110,380 Z" 
              fill="none"
              stroke={activeOrgan === 'large_intestine' ? organData.large_intestine.color : 'rgba(217, 119, 6, 0.8)'}
              strokeWidth="35"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.02 }}
              onClick={() => setActiveOrgan('large_intestine')}
              filter={activeOrgan === 'large_intestine' ? 'url(#glow)' : ''}
            />
            
            {/* Small Intestine */}
            <motion.path 
              d="M150,320 C180,300 220,340 180,360 C140,380 200,420 240,380 C280,340 240,320 260,350 C280,380 220,420 180,400 C140,380 160,340 150,320 Z" 
              fill="none"
              stroke={activeOrgan === 'small_intestine' ? organData.small_intestine.color : 'rgba(244, 114, 182, 0.8)'}
              strokeWidth="25"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="cursor-pointer transition-colors duration-300"
              whileHover={{ scale: 1.02 }}
              onClick={() => setActiveOrgan('small_intestine')}
              filter={activeOrgan === 'small_intestine' ? 'url(#glow)' : ''}
            />
          </svg>
        </div>

        {/* Info Panel */}
        <div className="w-full lg:w-96 h-[420px]">
          <AnimatePresence mode="wait">
            {activeOrgan ? (
              <motion.div
                key={activeOrgan + lang}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-full bg-slate-50 dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 flex flex-col overflow-y-auto"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white shrink-0" style={{ backgroundColor: organData[activeOrgan].color }}>
                    <Activity className="w-6 h-6" />
                  </div>
                  <h3 className={`text-2xl font-bold ${lang === 'kh' ? 'font-sans' : 'font-serif'}`}>
                    {organData[activeOrgan].name[lang]}
                  </h3>
                </div>
                
                <div className="space-y-5 flex-1">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-500 dark:text-slate-400 mb-1">
                      <Info className="w-4 h-4" /> {uiText[lang].function}
                    </div>
                    <p className={`text-slate-700 dark:text-slate-300 ${lang === 'kh' ? 'font-sans text-sm' : ''}`}>
                      {organData[activeOrgan].function[lang]}
                    </p>
                  </div>
                  
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-500 dark:text-slate-400 mb-2">
                      <AlertCircle className="w-4 h-4" /> {uiText[lang].conditions}
                    </div>
                    <ul className="space-y-2">
                      {organData[activeOrgan].conditions[lang].map((cond: string, i: number) => (
                        <li key={i} className={`flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 ${lang === 'kh' ? 'font-sans' : ''}`}>
                          <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: organData[activeOrgan].color }} />
                          {cond}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-500 dark:text-slate-400 mb-1">
                      <ShieldCheck className="w-4 h-4" /> {uiText[lang].prevention}
                    </div>
                    <p className={`text-slate-700 dark:text-slate-300 ${lang === 'kh' ? 'font-sans text-sm' : ''}`}>
                      {organData[activeOrgan].prevention[lang]}
                    </p>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl text-slate-400"
              >
                <Activity className="w-12 h-12 mb-4 opacity-50" />
                <p className={lang === 'kh' ? 'font-sans' : ''}>{uiText[lang].placeholder}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
