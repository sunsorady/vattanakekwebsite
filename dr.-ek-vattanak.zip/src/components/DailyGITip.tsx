import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lightbulb, X } from 'lucide-react';

const tips = [
  "Drink a glass of water first thing in the morning to kickstart digestion.",
  "Chew your food thoroughly; digestion begins in the mouth.",
  "Include probiotic-rich foods like yogurt or kimchi in your diet.",
  "Take a short walk after meals to aid digestion and lower blood sugar.",
  "Avoid eating heavy meals within 3 hours of bedtime to prevent acid reflux."
];

export default function DailyGITip() {
  const [isVisible, setIsVisible] = useState(false);
  const [tip, setTip] = useState('');

  useEffect(() => {
    const randomTip = tips[Math.floor(Math.random() * tips.length)];
    setTip(randomTip);
    
    // Show tip after 3 seconds
    const timer = setTimeout(() => setIsVisible(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          className="fixed top-24 left-6 max-w-xs bg-white/80 dark:bg-slate-800/80 backdrop-blur-md border border-emerald-200 dark:border-emerald-800 shadow-lg rounded-2xl p-4 z-40"
        >
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-semibold text-sm">
              <Lightbulb className="w-4 h-4" />
              <span>Daily GI Tip</span>
            </div>
            <button onClick={() => setIsVisible(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            {tip}
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
