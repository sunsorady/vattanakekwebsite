import { useState } from 'react';
import { motion } from 'motion/react';
import { Play, Search } from 'lucide-react';

const videos = [
  { id: 'iRU_5QkC8WY', title: 'Pathway to be Gastroenterologist 👩‍⚕️⚕️Dr. Ek Vatanak', category: 'Doctor life', views: '12k', duration: '1:48:30' },
  { id: 'dummy1', title: 'Understanding Acid Reflux & GERD', category: 'Patient education', views: '5k', duration: '12:45' },
  { id: 'dummy2', title: 'What to expect during a Colonoscopy', category: 'Gastroenterology', views: '8k', duration: '08:20' },
  { id: 'dummy3', title: 'Hemorrhoids: Causes and Treatments', category: 'Proctology', views: '15k', duration: '10:15' },
];

const categories = ['All', 'Gastroenterology', 'Proctology', 'Patient education', 'Doctor life'];

export default function VideosPage() {
  const [activeCat, setActiveCat] = useState('All');
  const [search, setSearch] = useState('');

  const filteredVideos = videos.filter(v => 
    (activeCat === 'All' || v.category === activeCat) &&
    v.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h1 className="text-4xl font-bold mb-4">Educational Videos</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Digestive health tips, endoscopy explanations, proctology insights and life journeys.
        </p>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCat(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${activeCat === cat ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
            >
              {cat}
            </button>
          ))}
        </div>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search videos..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 outline-none focus:border-rose-500 text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredVideos.map((video, i) => (
          <motion.div 
            key={video.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="group bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-slate-100 dark:border-slate-700 transition-all cursor-pointer"
          >
            <div className="relative aspect-video bg-slate-200 dark:bg-slate-700 overflow-hidden">
              <img 
                src={`https://img.youtube.com/vi/${video.id === 'dummy1' || video.id === 'dummy2' || video.id === 'dummy3' ? 'dQw4w9WgXcQ' : video.id}/hqdefault.jpg`} 
                alt={video.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                <div className="w-12 h-12 bg-rose-500 text-white rounded-full flex items-center justify-center scale-90 opacity-0 group-hover:scale-100 group-hover:opacity-100 transition-all shadow-lg">
                  <Play className="w-5 h-5 ml-1" />
                </div>
              </div>
              <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded font-medium">
                {video.duration}
              </div>
            </div>
            <div className="p-4">
              <div className="text-xs font-bold text-rose-500 mb-2 uppercase tracking-wider">{video.category}</div>
              <h3 className="font-bold text-lg mb-2 line-clamp-2 leading-tight">{video.title}</h3>
              <div className="text-sm text-slate-500">{video.views} views</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
