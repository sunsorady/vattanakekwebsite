import { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator, Activity, HeartPulse, BookOpen, ArrowRight } from 'lucide-react';

const topics = [
  { title: 'Acid Reflux & GERD', desc: 'Understanding the causes, symptoms, and treatments for chronic heartburn.', color: 'from-orange-400 to-rose-400' },
  { title: 'Hemorrhoids', desc: 'Effective management and modern treatment options for hemorrhoidal disease.', color: 'from-rose-400 to-pink-500' },
  { title: 'Fatty Liver Disease', desc: 'Lifestyle changes and medical interventions to protect your liver.', color: 'from-emerald-400 to-teal-500' },
  { title: 'Colon Cancer Screening', desc: 'Why colonoscopy saves lives and when you should get screened.', color: 'from-blue-400 to-indigo-500' },
  { title: 'Chronic Constipation', desc: 'Dietary adjustments and therapies for better bowel motility.', color: 'from-violet-400 to-purple-500' },
  { title: 'Irritable Bowel Syndrome', desc: 'Managing IBS symptoms through diet, stress reduction, and medication.', color: 'from-amber-400 to-orange-500' },
];

export default function ClinicalToolsPage() {
  const [activeTab, setActiveTab] = useState('meld');

  return (
    <div className="space-y-20">
      {/* Clinical Tools Section */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold mb-4">Medical Library</h1>
          <p className="text-slate-600 dark:text-slate-400">
            Interactive medical calculators for gastroenterology and hepatology.
            <br/><span className="text-xs text-blue-500">For educational purposes only.</span>
          </p>
        </div>

        <div className="flex justify-center gap-4 mb-8">
          {[
            { id: 'meld', label: 'MELD Score', icon: Activity },
            { id: 'child', label: 'Child-Pugh', icon: HeartPulse },
            { id: 'bmi', label: 'BMI Calculator', icon: Calculator }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all ${activeTab === tab.id ? 'bg-blue-500 text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-700'}`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-800 rounded-3xl shadow-xl p-8 border border-slate-100 dark:border-slate-700">
          {activeTab === 'meld' && <MeldCalculator />}
          {activeTab === 'child' && <ChildPughCalculator />}
          {activeTab === 'bmi' && <BmiCalculator />}
        </div>
      </div>

      {/* Education Section */}
      <div className="pt-16 border-t border-slate-200 dark:border-slate-800 space-y-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-4xl font-bold mb-4">Educational Articles</h2>
          <p className="text-slate-600 dark:text-slate-400">
            Clear, professional medical information to help you understand your digestive health.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topics.map((topic, i) => (
            <motion.div
              key={topic.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm hover:shadow-xl border border-slate-100 dark:border-slate-700 transition-all overflow-hidden cursor-pointer"
            >
              <div className={`absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r ${topic.color}`} />
              
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${topic.color} flex items-center justify-center text-white mb-6 shadow-lg group-hover:scale-110 transition-transform`}>
                <BookOpen className="w-6 h-6" />
              </div>
              
              <h3 className="text-xl font-bold font-serif mb-3">{topic.title}</h3>
              <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-6">
                {topic.desc}
              </p>
              
              <div className="flex items-center text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-500 transition-colors">
                Read Article <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MeldCalculator() {
  const [bilirubin, setBilirubin] = useState('');
  const [creatinine, setCreatinine] = useState('');
  const [inr, setInr] = useState('');
  const [score, setScore] = useState<number | null>(null);

  const calculateMeld = () => {
    const b = parseFloat(bilirubin);
    const c = parseFloat(creatinine);
    const i = parseFloat(inr);
    if (b && c && i) {
      // Simplified original MELD formula
      const m = 3.78 * Math.log(b) + 11.2 * Math.log(i) + 9.57 * Math.log(c) + 6.43;
      setScore(Math.round(m));
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <h2 className="text-2xl font-bold font-serif mb-6">MELD Score Calculator</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bilirubin (mg/dL)</label>
          <input type="number" value={bilirubin} onChange={e => setBilirubin(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Creatinine (mg/dL)</label>
          <input type="number" value={creatinine} onChange={e => setCreatinine(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">INR</label>
          <input type="number" value={inr} onChange={e => setInr(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <button onClick={calculateMeld} className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold hover:opacity-90 transition-opacity">
          Calculate Score
        </button>
      </div>
      
      {score !== null && (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl text-center border border-blue-100 dark:border-blue-800">
          <div className="text-sm text-blue-600 dark:text-blue-400 font-bold uppercase tracking-wider mb-2">Estimated MELD Score</div>
          <div className="text-5xl font-black text-slate-900 dark:text-white mb-2">{score}</div>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {score >= 40 ? '71.3% estimated 3-month mortality' : 
             score >= 30 ? '52.6% estimated 3-month mortality' : 
             score >= 20 ? '19.6% estimated 3-month mortality' : 
             '6.0% estimated 3-month mortality'}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}

function ChildPughCalculator() {
  const [bilirubin, setBilirubin] = useState('');
  const [albumin, setAlbumin] = useState('');
  const [inr, setInr] = useState('');
  const [ascites, setAscites] = useState('1');
  const [enceph, setEnceph] = useState('1');
  const [score, setScore] = useState<{points: number, class: string} | null>(null);

  const calculateChildPugh = () => {
    let points = 0;
    const b = parseFloat(bilirubin);
    const a = parseFloat(albumin);
    const i = parseFloat(inr);

    if (b && a && i) {
      if (b < 2) points += 1;
      else if (b <= 3) points += 2;
      else points += 3;

      if (a > 3.5) points += 1;
      else if (a >= 2.8) points += 2;
      else points += 3;

      if (i < 1.7) points += 1;
      else if (i <= 2.2) points += 2;
      else points += 3;

      points += parseInt(ascites);
      points += parseInt(enceph);

      let c = 'A';
      if (points >= 7 && points <= 9) c = 'B';
      if (points >= 10) c = 'C';

      setScore({ points, class: c });
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <h2 className="text-2xl font-bold font-serif mb-6">Child-Pugh Calculator</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Bilirubin (mg/dL)</label>
          <input type="number" value={bilirubin} onChange={e => setBilirubin(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Albumin (g/dL)</label>
          <input type="number" value={albumin} onChange={e => setAlbumin(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">INR</label>
          <input type="number" value={inr} onChange={e => setInr(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Ascites</label>
          <select value={ascites} onChange={e => setAscites(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500">
            <option value="1">Absent</option>
            <option value="2">Slight</option>
            <option value="3">Moderate/Severe</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Encephalopathy</label>
          <select value={enceph} onChange={e => setEnceph(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500">
            <option value="1">None</option>
            <option value="2">Grade I-II</option>
            <option value="3">Grade III-IV</option>
          </select>
        </div>
        <button onClick={calculateChildPugh} className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold hover:opacity-90 transition-opacity">
          Calculate Score
        </button>
      </div>
      
      {score !== null && (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl text-center border border-blue-100 dark:border-blue-800">
          <div className="text-sm text-blue-600 dark:text-blue-400 font-bold uppercase tracking-wider mb-2">Child-Pugh Class</div>
          <div className="text-5xl font-black text-slate-900 dark:text-white mb-2">{score.class}</div>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Total Points: {score.points}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}

function BmiCalculator() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);

  const calculateBmi = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // cm to m
    if (w && h) {
      setBmi(Math.round((w / (h * h)) * 10) / 10);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <h2 className="text-2xl font-bold font-serif mb-6">BMI Calculator</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Weight (kg)</label>
          <input type="number" value={weight} onChange={e => setWeight(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Height (cm)</label>
          <input type="number" value={height} onChange={e => setHeight(e.target.value)} className="w-full px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 outline-none focus:border-blue-500" />
        </div>
        <button onClick={calculateBmi} className="w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-bold hover:opacity-90 transition-opacity">
          Calculate BMI
        </button>
      </div>
      
      {bmi !== null && (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl text-center border border-blue-100 dark:border-blue-800">
          <div className="text-sm text-blue-600 dark:text-blue-400 font-bold uppercase tracking-wider mb-2">Your BMI</div>
          <div className="text-5xl font-black text-slate-900 dark:text-white mb-2">{bmi}</div>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-4">
            {bmi < 18.5 ? 'Underweight. May impact nutrient absorption.' : 
             bmi < 25 ? 'Normal weight. Good for overall GI health.' : 
             bmi < 30 ? 'Overweight. Increased risk of GERD and fatty liver.' : 
             'Obese. High risk of fatty liver disease and GERD.'}
          </p>
        </motion.div>
      )}
    </motion.div>
  );
}
